wget -qO- "http://wimaxrf:5052/wimaxrf/bs/set?arq=0"  
wget -qO- "http://wimaxrf:5052/wimaxrf/bs/restart"  