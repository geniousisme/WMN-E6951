omf load -i baseline-witest.ndz -t omf.witest.node7  
omf tell -a on -t omf.witest.node7  