wget -qO- "http://wimaxrf:5052/wimaxrf/bs/set?arq=1"  
wget -qO- "http://wimaxrf:5052/wimaxrf/bs/set?arq_block_size=1024"  
wget -qO- "http://wimaxrf:5052/wimaxrf/bs/restart"  